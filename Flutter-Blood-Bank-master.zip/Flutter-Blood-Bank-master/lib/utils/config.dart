class Configs {
  static String appname = "Blood Donation ";
  static String rooturl = "https://mohnyin.net/api/v1/admin/";
  static String appversion = "0.0.1 beta";
}
