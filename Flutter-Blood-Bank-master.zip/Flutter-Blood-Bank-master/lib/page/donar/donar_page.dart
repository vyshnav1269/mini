import 'package:flutter/material.dart';

class DonarPage extends StatefulWidget {
  DonarPage({Key key}) : super(key: key);

  @override
  _DonarPageState createState() => _DonarPageState();
}

class _DonarPageState extends State<DonarPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
   
    );
  }
}